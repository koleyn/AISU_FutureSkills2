import pygame
import sys
import sqlite3
import pandas as pd
import tkinter as tk

bd = sqlite3.connect("database")
cur = bd.cursor()


cur.execute("""
create table if not exists RECORDS (
name, text,
score integer
)

""")

cur.execute("""
SELECT name KRL, max(score) from RECORDS
GROUP by name 
ORDER by score DESC 
limit 3
""")

result = cur.fetchall()
print(result)
cur.close()

pygame.init()

window = pygame.display.set_mode((1090, 1000))
track = pygame.image.load('road.png')
car = pygame.image.load('car.png')
man = pygame.image.load('human.png')
zebra = pygame.image.load('zebra1.png')
man1 = pygame.image.load('human.png')
zebra1 = pygame.image.load('zebra1.png')
man3 = pygame.image.load('human.png')
wart = pygame.image.load('zebra2.png')
man4 = pygame.image.load('human.png')
wart2 = pygame.image.load('zebra2.png')
zebra = pygame.transform.scale(zebra, (40, 100))
wart = pygame.transform.scale(wart, (100, 40))
wart2 = pygame.transform.scale(wart2, (95, 40))
car = pygame.transform.scale(car, (65, 35))
man_x = 215
man_y = 740

man1_x = 215
man3_x = 290
man4_x = 798

man1_y = 532
man3_y = 320
man4_y = 530

zebra_x = 223
zebra_y = 785

zebra1_x = 210
zebra1_y = 575


zebraB1_x = 333
zebraB1_y = 320

zebraB2_x = 830
zebraB2_y = 535

car_x = 920
car_y = 795
drive = True
wolk = True
clock = pygame.time.Clock()
clock2 = pygame.time.Clock()
focal_dis = 45
focal_wolk_dis = 10
cam_x_offset = 0
cam_y_offset = 0
cam2_x_offset = 0
cam2_y_offset = 0
direction = 'left'
direction2 = 'down'


class Button():
    def __init__(self, x, y, width, height, inactive_color, active_color):
        self.width = 1090
        self.height = 1000
        self.inactive_clr = (23, 204, 58)
        self.active_clr = (13, 162, 58)

    def draw(self, x, y, message, action=None):
        mouse = pygame.mouse.get.pos()
        click = pygame.mouse.get.pressed()

        if x < mouse[0] < x + self.width:
            if y < mouse[0] < y + self.height:
                pygame.draw.rect(window,self.active_clr, (x, y, self.width, self.height))

                if click[0] == 1:
                    pygame.time.delay(300)
                    if action is not None:
                        action()


            else:
                pygame.draw.rect(window, self.inactive_clr, (x, y, self.width, self.height))


while wolk:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            wolk = False
    clock2.tick(100)
    cam2_x = man_x + cam2_x_offset + 5
    cam2_y = man_y + cam2_y_offset + 5
    up_px = window.get_at((cam2_x, cam2_y - focal_wolk_dis))[0]
    down_px = window.get_at((cam2_x, cam2_y + focal_wolk_dis))[0]
    print(up_px, down_px)

    if direction2 == 'down' and down_px == 127:
        man_y = man_y - 1
    elif direction2 == 'up' and up_px == 249:
        man_y = man_y + 1
    elif direction == 'down' and down_px == 255:
        man_y = man_y - 1


    clock.tick(110)
    cam_x = car_x + cam_x_offset + 18
    cam_y = car_y + cam_y_offset + 18
    up_px = window.get_at((cam_x, cam_y - focal_dis))[0]
    down_px = window.get_at((cam_x, cam_y + focal_dis))[0]
    right_px = window.get_at((cam_x + focal_dis, cam_y))[0]
    left_px = window.get_at((cam_x - focal_dis, cam_y))[0]
    print(up_px, right_px, down_px, left_px)

    if direction == 'up' and up_px != 127 and right_px == 127:
        direction = 'right'
        car_y = car_y + 30
        cam_x_offset = 10
        car = pygame.transform.rotate(car, -90)

    elif direction == 'right' and right_px != 127 and up_px == 127:
        direction = 'up'
        car_x = car_x + 30
        cam_y_offset = 10
        car = pygame.transform.rotate(car, 90)

    elif direction == 'down' and down_px != 127 and right_px == 127:
        direction = 'right'
        car_x = car_x + 30
        cam_x_offset = 30
        car = pygame.transform.rotate(car, 90)

    elif direction == 'down' and down_px != 127 and left_px == 127:
        direction = 'left'
        car_x = car_x + 30
        cam_x_offset = 0
        car = pygame.transform.rotate(car, -90)

    elif direction == 'up' and up_px != 127 and left_px == 127:
        direction = 'left'
        car_x = car_x - 30
        cam_x_offset = 0
        car = pygame.transform.rotate(car, 90)

    elif direction == 'left' and left_px != 127 and up_px == 127:
        direction = 'up'
        car_x = car_x + 30
        cam_x_offset = 0
        car = pygame.transform.rotate(car, -90)

    if direction == 'up' and up_px == 127:
        car_y = car_y - 2
    elif direction == 'right' and right_px == 127:
        car_x = car_x + 2
    elif direction == 'right' and right_px == 255:
        car_x = car_x + 1
    elif direction == 'down' and down_px == 127:
        car_y = car_y + 2
    elif direction == 'left' and left_px == 127:
        car_x = car_x - 2
    elif direction == 'left' and left_px == 255:
        car_x = car_x - 1


    window.blit(track, (0, 0))
    window.blit(man, (man_x, man_y))
    window.blit(zebra, (zebra_x, zebra_y))

    window.blit(zebra, (zebra1_x, zebra1_y))
    window.blit(man1, (man1_x, man1_y))
    window.blit(man3, (man3_x, man3_y))
    window.blit(wart, (zebraB1_x, zebraB1_y))
    window.blit(man4, (man4_x, man4_y))
    window.blit(wart2, (zebraB2_x, zebraB2_y))
    window.blit(car, (car_x, car_y))

    pygame.draw.circle(window, (0, 0, 0), (cam_x, cam_y), 1, 1)
    pygame.draw.circle(window, (255, 255, 200), (cam2_x, cam2_y), 1, 1)
    pygame.display.update()