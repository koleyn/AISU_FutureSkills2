import pygame
from random import choice
import sqlite3
import math
pygame.init()
db = sqlite3.connect('my.db')
cur = db.cursor()
cur.execute('''CREATE TABLE IF NOT EXISTS Cars_stat(
                title TEXT,count int)''')
cur.execute('''CREATE TABLE IF NOT EXISTS Traffic_object(
                title TEXT,count int)''')
window = pygame.display.set_mode((1100, 650))
track=pygame.image.load('road.png')
drive=True
car = pygame.image.load('BCbottom.png')
svet=pygame.image.load('TLgreen.png')
car_x = 320
car_y = 20
focal_dis = 25
cam_x_offset = 0
cam_y_offset = 0
direction = 'down'

clock = pygame.time.Clock()
speed=2

button_rect=svet.get_rect(topleft=(1050,100))
font = pygame.font.SysFont('Arial', 15, 1, 0)
text = font.render("Удалить", True, (0,0,0))
text2= font.render("Подключить", True, (0,0,0))
text3= font.render("Таблица", True, (0,0,0))
button_rect2=text.get_rect(topleft=(1020,200))
button_rect3=text2.get_rect(topleft=(1000,250))
button_rect4=text3.get_rect(topleft=(1020,300))
press=False
press2=False
ab=[]
key = [1, 2,3]
key2=[1,2]
my_choose = choice(key)
my_choose2 = choice(key2)
print(my_choose)

import tkinter as tk

win = tk.Tk()

def onclick():
    win.destroy()
button = tk.Button(win, text="Test", command=onclick)
button.grid(row=1, column=1)
button.place(relx=0.5, rely=0.5, anchor='center')
screen_width = 1920


x_cordinate = 900

y_cordinate = 500

win.geometry("{}x{}+{}+{}".format(100, 20, x_cordinate, y_cordinate))

win.mainloop()
count=0
count2=0
count3=0
start_ticks=pygame.time.get_ticks()
seconds=(pygame.time.get_ticks()-start_ticks)/1000
cur.execute('delete from Cars_stat')
cur.execute('delete from Traffic_object')
values = 'Выезд из города'
cur.execute("insert into Cars_stat(title,count) values(?,?)", (values, count))
values2 = 'Въезд в город'
cur.execute("insert into Cars_stat(title,count) values(?,?)", (values2, count2))
values3 = 'Был светофор'
cur.execute("insert into Traffic_object(title,count) values(?,?)", (values3,count3))


def start():
    count3=0
    window.blit(track, (0, 0))
    #window.blit(svet, (1050, 50))
    window.blit(car, (car_x, car_y))
    window.blit(svet,button_rect)
    window.blit(text, button_rect2)
    window.blit(text2, button_rect3)
    window.blit(text3, button_rect4)
    for i in ab:
        window.blit(svet,(i[0],i[1]))
        distance = math.sqrt(math.pow(car_x - i[0], 2) + math.pow(car_y - i[1], 2))
        #print(distance)
        if 12.5<distance<13:
            count3+=1
            cur.execute("update Traffic_object set count==? where title==?", (count3, values3))
            d = cur.execute("SELECT* from Traffic_object").fetchone()
            #print('Светофор', ' ', 'Количесво')
            #print(d[0])




while drive:
    #print(pesh1)
    secondss=(pygame.time.get_ticks()-start_ticks)/1000

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            drive = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 3:
                if button_rect.collidepoint(event.pos):
                    if press == True:
                        press = False
                    else:
                        press = True

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 3:
                if button_rect2.collidepoint(event.pos):
                    if press2 == True:
                        press2 = False
                    else:
                        press2 = True
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 3:
                if button_rect3.collidepoint(event.pos):
                    print('есть подключение')
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 3:
                if button_rect4.collidepoint(event.pos):
                    cur.execute("update Cars_stat set count==? where title==?", (count, values))
                    a = cur.execute("SELECT* from Cars_stat").fetchone()
                    values2 = 'Въезд в город'
                    cur.execute("update Cars_stat set count==? where title==?", (count2, values2))
                    b= cur.execute("SELECT* from Cars_stat").fetchone()
                    cur.execute("update Traffic_object set count==? where title==?", (count3, values3))
                    d = cur.execute("SELECT* from Traffic_object").fetchone()

                    print('Выезд или въезд', ' ','Количесво выездов','Светофор',)
                    print(a[0],'   ',a[1])
                    print(d[0])
                    

    cam_x = car_x + cam_x_offset + 15
    cam_y = car_y + cam_y_offset + 15
    up_px = window.get_at((cam_x, cam_y - focal_dis))[0]
    down_px = window.get_at((cam_x, cam_y + focal_dis))[0]
    right_px = window.get_at((cam_x + focal_dis, cam_y))[0]
    left_px = window.get_at((cam_x - focal_dis, cam_y))[0]
    #print(down_px)
    right_px2 = window.get_at((cam_x + focal_dis, cam_y))[1]
    clock.tick(60)
    # change direction (take turn)

    if direction == 'up' and up_px != 127 and (right_px == 127 or right_px == 0):
        direction = 'right'
        focal_dis = 30
        cam_x_offset = 15
        car = pygame.transform.rotate(car, -90)


    elif direction == 'right' and right_px != 127 and (down_px == 127 or down_px == 0):
        direction = 'down'
        focal_dis = 30
        car_x = car_x + 30
        cam_x_offset = 0
        cam_y_offset = 15
        car = pygame.transform.rotate(car, -90)

    elif direction == 'down' and down_px != 127 and (right_px == 127 or right_px == 0):
        direction = 'right'
        #focal_dis = 25
        car_y = car_y + 30
        cam_x_offset = 15
        cam_y_offset = 0
        car = pygame.transform.rotate(car, 90)
    elif direction == 'down' and down_px != 127 and (left_px == 127):
        direction = 'left'
        #focal_dis=20
        car_y = car_y + 30
        cam_x_offset = -15
        cam_y_offset = 0
        car = pygame.transform.rotate(car, -90)

    elif direction == 'right' and right_px != 127 and up_px == 127 and right_px != 0 and right_px2 != 0:
        direction = 'up'
        #focal_dis = 30
        car_x = car_x + 30
        cam_x_offset = 0
        car = pygame.transform.rotate(car, 90)

    elif direction == 'left' and left_px!=127 and down_px==127:
        direction = 'down'
        #focal_dis=20
        car_x = car_x
        cam_x_offset = 0
        cam_y_offset = 15
        car = pygame.transform.rotate(car, 90)

    if car_x==430 and car_y==50 and my_choose==1:

        direction='right'


    elif car_x==430 and (car_y==50 or car_y==60) and my_choose==2:
        focal_dis=40
        direction = 'down'
        car_x=car_x+30
        cam_x_offset = 0
        cam_y_offset = 15
        car = pygame.transform.rotate(car, -90)

    elif car_x==650 and car_y==50 and my_choose==3:
        focal_dis=40
        direction = 'down'
        car_x=car_x+30
        cam_x_offset = 0
        cam_y_offset = 15
        car = pygame.transform.rotate(car, -90)

    elif car_x == 460 and car_y == 414 and my_choose == 2 and my_choose2==1:
        focal_dis = 40
        direction = 'left'
        # car_x = car_x + 30
        # cam_x_offset = 0
        # cam_y_offset = 15
        car = pygame.transform.rotate(car, -90)


    if (car_x==866 and car_y==580):
        count += 1
        count3=0
        car_x=320
        car_y=20
        focal_dis=30
        my_choose=choice(key)
        my_choose2 = choice(key2)
        values = 'Выезд из города'
        cur.execute("update Cars_stat set count==? where title==?", (count,values))
        a = cur.execute("SELECT* from Cars_stat").fetchone()
        db.commit()
        #print(a)
        #print(my_choose)
    elif (car_x==840 and car_y==570):
        count+=1
        count3 = 0
        car_x=320
        car_y=20
        focal_dis=30
        my_choose=choice(key)
        my_choose2 = choice(key2)
        values = 'Выезд из города'
        cur.execute("update Cars_stat set count==? where title==?", (count,values))
        a = cur.execute("SELECT* from Cars_stat").fetchone()
        db.commit()
        #print(a)
        #print(my_choose)
    if (car_x==320 and car_y==20):
        count2+=1
        count3 = 0
        values2 = 'Въезд в город'
        cur.execute("update Cars_stat set count==? where title==?", (count2,values2))
        a = cur.execute("SELECT* from Cars_stat").fetchone()
        db.commit()

    # drive
    if direction == 'up' and (up_px == 127 or up_px==0):
        car_y = car_y - speed
    elif direction == 'right' and (right_px == 127 or right_px==0):
        car_x = car_x + speed
    elif direction == 'down' and (down_px == 127):
        car_y = car_y + speed
    elif direction == 'right' and (right_px2 == 250 or right_px == 0):
        car_x = car_x + speed
    elif direction=='left' and left_px==127:
        car_x=car_x-speed


    start()
    if press:
        pygame.draw.rect(window,(0,0,0),(button_rect),1)
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                a = pygame.mouse.get_pos()
                pxx = window.get_at((a[0],a[1]))[0]
                if a[0] < 1100 and a[1] < 650 and pxx==127:
                    ab.append(window.blit(svet,(a[0],a[1])))
    if press2:
        pygame.draw.rect(window,(0,0,0),(button_rect2),1)
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                find = [s for s in ab if s.collidepoint(event.pos)]
                for i in find:
                    pygame.draw.rect(window,(255,255,0), (i), 2)
                    ab.remove(i)
                    for d in ab:
                        pygame.display.update(d)
                        window.blit(svet, d)
                        pygame.display.flip()


    #print(car_x,car_y)
    pygame.display.update()